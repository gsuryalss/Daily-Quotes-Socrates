=== Daily Quotes Socrates ===
Contributors: gsuryalss
Tags: daily quotes, quotes, socrates, socrates quote, leadership, love, peace, philosophy, daily quote, quote of the day, inspirational
Requires at least: 3.0
Tested up to: 4.7.2
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


This plugin helps to display random Socrates Quotes over the website.


== Description ==

Displays random Socrates quotes over the website.

== Installation ==

**Follow the steps to install the plugin:**

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly by searching "Daily Quotes Socrates" plugin.
2. Activate the plugin through the 'Plugins' screen in WordPress

After installing the plugin, Navigate to Appearance -> Widget and then add the widget "Quotes by Socrates".
Random Quotes will be displayed in the website as per your widget/Theme settings.
